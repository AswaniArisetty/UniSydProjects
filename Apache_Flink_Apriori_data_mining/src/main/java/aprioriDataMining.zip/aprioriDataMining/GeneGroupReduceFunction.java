package aprioriDataMining;

public class GeneGroupReduceFunction {

}
